package orc.test;

import java.sql.*;
import oracle.jdbc.*;
import oracle.jdbc.pool.OracleDataSource;
import java.sql.SQLException;
import org.jooq.DSLContext;
import org.jooq.Record;
import org.jooq.SQLDialect;
import org.jooq.impl.DSL;
import org.jooq.*;
import org.jooq.impl.*;

import orc.test.tables.Emp;
import orc.test.tables.Dept;
import org.jooq.Result;
import org.jooq.Select;



	public class Test_JSPV2 {
			
		// Variable Declaration
		String userName = "c##scott";
        String password = "tiger";
   
        Connection conn=null;
        DSLContext create=null;
        Result result=null;
        
        static long lowestFetchTime=99999999;
        static long tempFetchTime=0;
        static long highestFetchTime=0;
		        
        
		public static void calculate() {
			
	 			for (int loop = 0;  loop < 20; loop++) {
						tempFetchTime = executer();
	 
				if(tempFetchTime<lowestFetchTime) 
						lowestFetchTime=tempFetchTime;
			 						
				if(tempFetchTime>highestFetchTime) 
						highestFetchTime=tempFetchTime;
			  						
				}
 
				System.out.println("|||| The Lowest Execution Time  |||| --->>> "+lowestFetchTime);
				System.out.println("|||| The Highest Execution Time  |||| --->>> "+highestFetchTime);
	       	        // reset
				lowestFetchTime=99999999;
		        tempFetchTime=0;
		        highestFetchTime=0;
	    }
		
				
		   //Get a JDBC connection and create JOOQ DSL context
	     
		 public DSLContext getJOOQContext(){
    	   
    	   try {
    	   
    		   OracleDataSource ods = new OracleDataSource();
	           ods.setURL("jdbc:default:connection");
	           conn = ods.getConnection();
	           create = DSL.using(conn, SQLDialect.ORACLE);
    	           return create;
    	           
    	      }catch (SQLException e) {
    		   e.printStackTrace();
    	   }
			return create;
			
       }
		 		 
		 
		  // Construct a JOOQ query and execute 
		   
		 public Result executeQueri(){ 
			 
     		 Select queri = create.select(Emp.EMP.ENAME, Dept.DEPT.DNAME, Emp.EMP.JOB, Emp.EMP.EMPNO,Emp.EMP.HIREDATE).from(Emp.EMP).join(Dept.DEPT).on(Dept.DEPT.DEPTNO.eq(Emp.EMP.DEPTNO)).orderBy(Emp.EMP.ENAME);
     		 result =  queri.fetch();
    	     return result;
    	     
        }
		 
		 
		 //Execute Query N Times when the executer method is called & print the time
		 
		 public static long executer() {
			 
			 	long timeDiff=0;
			 	 Test_JSPV2 TJ= new  Test_JSPV2();
				
		        long start = System.currentTimeMillis();
		        TJ.create=TJ.getJOOQContext();
		        
		        for (int loop = 0;  loop < 640; loop++) {
				TJ.result= TJ.executeQueri();
		        }
		        
		        timeDiff=System.currentTimeMillis()-start;
		        System.out.println("--->>>--------Execution Time----------->>>   "+timeDiff);
		        System.out.println(TJ.result);
		        TJ.close();
		        
		        return (timeDiff);
		        			 
		 }
		 
		 public void close() {
			 
			 try {
			    this.conn.close();
		        create=null;
		        Result result=null;
			  }catch (SQLException e) {
	     		   e.printStackTrace();
	     	   }
		  
		 }
		
		
	}
